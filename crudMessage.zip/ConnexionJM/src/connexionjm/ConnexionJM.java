/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package connexionjm;
import java.sql.*;
/**
 *
 * @author Said
 */
public class ConnexionJM {
 static Connection cnx;
 static Statement st;
 static Statement st2;
 static ResultSet rst;
 static ResultSet rst2;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
         //AjouterP(100,"AAAA",50.50,15,"Informatique",1);
        
        //SupprimerParID(3);
        
        //recherchePparLibelle("SOURIS11");
        
        
        rechercheParUtilisateur(3);
        rechercheParDiscussion(1);
        AjouterMessage("salut Med ",1,1);
        SupprimerMessage(9);
        ModifierMessage(3,"je suis Bilel Kammoun");
        
          try{
              cnx=connecterDB(); 
              st=cnx.createStatement();
              rst=st.executeQuery("SELECT * FROM message");
              
              while(rst.next()){
                  System.out.print(rst.getInt("id_message")+"\t");
                  System.out.print(rst.getString("message")+"\t");
                  
                  System.out.print(rst.getInt("id_utilisateur")+"\t");
              
                  System.out.print(rst.getInt("id_discussion")+"\t");
                  System.out.println();
              }
          }catch(Exception ex){
              ex.printStackTrace();
          } 
     
    }
    
  
    
    public static Connection  connecterDB(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            //System.out.println("Driver oki");
            String url="jdbc:mysql://localhost:3306/myapplication";
            String user="root";
            String password="";
           Connection cnx=DriverManager.getConnection(url,user,password);
           // System.out.println("Connexion bien établié");
            return cnx;
        }catch(Exception e){
            e.printStackTrace();
            return null;
        }
    }
   
    public static void AjouterMessage(String Message,int id_utilisateur,int id_discussion){
        try{
            String query="INSERT INTO message(message,id_utilisateur,id_discussion) VALUES(?,?,?)";
            cnx=connecterDB();
            PreparedStatement ps = cnx.prepareStatement(query);
            ps.setString(1, Message);
            ps.setInt(2, id_utilisateur);
            ps.setInt(3, id_discussion);
            ps.executeUpdate();
            
            System.out.println("Message bien ajouté");
            
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
        
        
    }
   
    public static void SupprimerMessage(int id){
        try{
           String query="DELETE FROM message WHERE id_message="+id; 
           cnx=connecterDB();
           st=cnx.createStatement();
           st.executeUpdate(query);
           System.out.println("Message Supprimé bien supprimé");
            
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
    }
   
    public static void rechercheParDiscussion(int id_discussion){
        try{
           String query="SELECT * FROM message WHERE id_discussion='"+id_discussion+"'"; 
           cnx=connecterDB();
           st=cnx.createStatement();
           rst= st.executeQuery(query);
           while (rst.next()){
        
            rechercheParUtilisateur(rst.getInt(3));
           System.out.print(rst.getString(2)+"\n");
         
           }
           
            
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
        
    }
    
    
        public static void  rechercheParUtilisateur(int id_utilisateur){
        try{
           String query="SELECT * FROM utilisateur WHERE id_utilisateur='"+id_utilisateur+"'"; 
           cnx=connecterDB();
           st=cnx.createStatement();
           rst= st.executeQuery(query);
          
      
          while (rst.next()){ 
         
       
           System.out.println(rst.getString("nom") + rst.getString("Prenom")+"\n");
       
          }
          
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
    
     
     
        
    }
    
    
    
   public static void ModifierMessage(int id_message,String Message){
       try{
           String query="update message set message=? where id_message=?";
           cnx=connecterDB();
            PreparedStatement ps = cnx.prepareStatement(query);
            ps.setString(1, Message);
            ps.setInt(2, id_message);
           
            ps.executeUpdate();
           
       }catch(SQLException e){
           System.out.println(e.getMessage());
       }
       
       
   }
    
    
    
    
   
    
}
